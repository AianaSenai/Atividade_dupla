package com.projeto.senai.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.Map;

@RestControllerAdvice

public class GlobalException {
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity <Map<?,?>> IllegalArgumentException(IllegalArgumentException erro){
        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(Map.of("mennsagem",erro.getMessage()));

    }
}
